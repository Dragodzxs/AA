FAQ_KNOWLEDGE_BASE = [
    {
        "keywords": ["wfh", "remote", "home", "hybrid", "telecommute"],
        "answer": "Under the Bennett Enterprise Remote Policy (Sec 4.1), full-time staff can work remotely up to 3 days per week. Synchronous core working hours are strictly between 10:00 AM and 3:00 PM (IST). Mandatory in-office days are Tuesdays and Thursdays for all engineering teams.",
        "citations": ["Remote Work Policy 2026", "Employee Handbook Sec. 4.1", "Telecommuting Agreement 2.0"],
        "suggestions": ["Who approves my remote work schedule?", "Can I work remotely during hackathons?", "What is the home internet allowance?"]
    },
    {
        "keywords": ["leave", "vacation", "holiday", "pto", "sick", "absence", "fmla", "maternity", "parental"],
        "answer": "Employees accrue 21 days of Paid Time Off (PTO) annually. Sick leave (up to 12 days) under 2 days requires self-certification; longer absences require a medical certificate. Parental leave covers 16 weeks of fully paid leave for the primary caregiver under the Global Family Policy.",
        "citations": ["Annual Leave Policy Sec. 2", "Global Family Policy 2026", "Manager Approval Matrix"],
        "suggestions": ["How do I apply for casual leave?", "View official company holiday list", "What are the rules for unpaid leave?"]
    },
    {
        "keywords": ["reimburse", "expense", "hackathon", "grant", "allowance", "hardware", "cloud", "azure", "per diem"],
        "answer": "For Microsoft Innovate 2026 (Project #279), team members are eligible for up to ₹5,000 each in verified hardware components and Azure cloud compute credits. Standard business travel provides a per diem of ₹1,500. Submit GST invoices within 30 days via the SAP Concur finance portal.",
        "citations": ["Hackathon Innovation Grant Memo #279", "Corporate Travel & Expense Policy Sec. 5.1"],
        "suggestions": ["Where do I upload invoice receipts?", "Are cloud API tokens eligible for reimbursement?", "What is the reimbursement timeline?"]
    },
    {
        "keywords": ["insurance", "health", "medical", "dental", "hospital", "wellness", "vision"],
        "answer": "All team members are enrolled in the Enterprise Comprehensive Health Cover (up to ₹5,00,000 sum insured per family) with cashless hospitalization across 4,500+ network hospitals. The wellness program also includes a ₹10,000 annual allowance for gym memberships and mental health counseling.",
        "citations": ["Corporate Health & Wellness Benefit Sec. 8", "Mental Health Support Memo"],
        "suggestions": ["Download digital insurance e-card", "List of network empaneled hospitals", "How to submit outpatient medicine bills?"]
    },
    {
        "keywords": ["nda", "confidentiality", "ip", "intellectual property", "open source", "proprietary", "patent"],
        "answer": "All code, algorithms, and models developed during employment or company-sponsored hackathons (including Team Glitch Theory) remain the exclusive intellectual property of the enterprise. Any intention to open-source project components requires prior written clearance from the Legal and Compliance Office.",
        "citations": ["Enterprise IP & Confidentiality Agreement", "Legal Code of Conduct Sec. 3.2"],
        "suggestions": ["How do I request open-source clearance?", "What happens if I use external open-source libraries?", "Where can I read the full NDA?"]
    },
    {
        "keywords": ["harassment", "eeo", "discrimination", "equal opportunity", "diversity", "inclusion", "report"],
        "answer": "The enterprise enforces a zero-tolerance policy against workplace harassment, bullying, and discrimination. We are strictly an Equal Employment Opportunity (EEO) employer. Violations can be reported anonymously through the Ethics Hotline or directly to the HR Business Partner.",
        "citations": ["Anti-Harassment & Discrimination Policy", "EEO Compliance Guide", "Whistleblower Protection Act"],
        "suggestions": ["How do I file an anonymous grievance?", "Who is my HR Business Partner?", "What constitutes workplace harassment?"]
    },
    {
        "keywords": ["data privacy", "gdpr", "pii", "security", "phishing", "compliance", "customer data"],
        "answer": "Handling of Personally Identifiable Information (PII) must strictly adhere to GDPR and internal Data Privacy frameworks. Customer or employee data must never be stored on local drives or personal cloud accounts. All unauthorized access or phishing attempts must be reported to InfoSec immediately.",
        "citations": ["Data Privacy & GDPR Framework 2026", "Information Security (InfoSec) Policy", "Data Handling Guidelines"],
        "suggestions": ["How do I classify confidential data?", "What should I do if I clicked a phishing link?", "How do I request database access?"]
    },
    {
        "keywords": ["termination", "severance", "resign", "notice period", "offboarding", "exit"],
        "answer": "The standard notice period for voluntary resignation is 60 days. In cases of involuntary termination without cause, employees are entitled to a severance package equivalent to 1 month's base salary per year of service. All physical assets and access badges must be surrendered on the last working day.",
        "citations": ["Employee Exit & Offboarding Guidelines", "Severance & Separation Agreement"],
        "suggestions": ["What happens to my unvested equity?", "Can the notice period be bought out?", "How is my final settlement calculated?"]
    },
    {
        "keywords": ["social media", "public communication", "press", "media", "twitter", "linkedin", "blogging"],
        "answer": "Employees may not speak to the press or post on social media on behalf of the company without explicit authorization from Corporate Communications. When discussing work-related topics online, employees must state that their views do not represent the enterprise.",
        "citations": ["Corporate Social Media Policy", "Public Relations & Media Guidelines"],
        "suggestions": ["Can I post about my hackathon project on LinkedIn?", "Who handles press inquiries?", "What are the rules for personal tech blogs?"]
    },
    {
        "keywords": ["compensation", "overtime", "bonus", "flsa", "salary", "paycheck", "payroll"],
        "answer": "Base salaries are credited on the last working day of each month. Overtime pay (1.5x hourly rate) is only applicable to non-exempt employees pre-approved by their manager. The annual performance bonus is distributed in Q1 based on the previous year's individual and company performance metrics.",
        "citations": ["Payroll & Compensation Guide", "Annual Bonus Framework", "Overtime Approval Matrix"],
        "suggestions": ["Where can I view my payslips?", "How is the performance bonus calculated?", "How do I update my tax withholding status?"]
    },
    {
        "keywords": ["escalate", "human", "agent", "sarah", "talk to human", "representative", "contact hr"],
        "answer": "I have escalated your session to Sarah Jenkins from Human Resources. She will review your employee record and assist you shortly.",
        "citations": ["HR Service Level Agreement 2026", "Direct Representative Hand-off"],
        "suggestions": ["Schedule a confidential 1-on-1 call", "Check status of open HR tickets", "Submit employee grievance form"],
        "escalated": True,
        "agentName": "Sarah Jenkins"
    }
]
